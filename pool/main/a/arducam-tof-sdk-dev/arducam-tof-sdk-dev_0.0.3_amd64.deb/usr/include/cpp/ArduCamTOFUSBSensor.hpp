
#ifndef __TOF_USB_CAMERA_H
#define __TOF_USB_CAMERA_H

#include <unistd.h>
#include <thread>
#include <time.h>
#include <iostream>
#include <string>
#include "arducam_config_parser.h"
#include "ArduCamLib.h"

#include "Semaphore.hpp"

#include "ArduCamTOFSensor.hpp"

namespace ArduCam
{

	class ArduCamTOFUSBSensor : public ArduCamTOFSensor
	{
	public:
		ArduCamTOFUSBSensor(const int video_index = 0);
		ArduCamTOFUSBSensor(const char *cfg_path,const int video_index = 0);

		~ArduCamTOFUSBSensor() = default;

		int open() override;

		int close() override;

		int start() override;

		int stop() override;

		int getFrame(uint8_t *data_ptr, struct timeval &timestamp) override;

		int setControl(ControlID mode, int value) override;

	private:
		void capture();
		void returnFrameBuffer();
		void configBoard(ArduCamHandle &cameraHandle, Config config);
		bool camera_initFromFile(std::string filename, ArduCamHandle &cameraHandle, ArduCamCfg &cameraCfg, int index);
		bool camera_init(ArduCamHandle &cameraHandle, ArduCamCfg &cameraCfg, int index);
		void setRange(int value);
	private:
		ArduCamHandle handle;
		ArduCamCfg cameraCfg;
		ArduCamOutData *frameData;
		bool _running;
		std::string video_cfg;
		int video_index;
	};
}

#endif