#ifndef __TOF_SENSOR_H
#define __TOF_SENSOR_H

#include "ArduCamTOFUnity.hpp"
namespace ArduCam
{
    /**
     * @brief Direct operation class for camera
     * 
     */
    class ArduCamTOFSensor
    {
    public:
        ArduCamTOFSensor() = default;

        virtual ~ArduCamTOFSensor() = default;

    public:
        /**
         * @brief Open the camera 
         *
         * @return Return Status code.
         */
        virtual int open() = 0;
        
        /**
         * @brief Close camera
         *
         * @return Return Status code.
         */
        virtual int close() = 0;

        /**
         * @brief Start the camera stream.
         *
         * @return Return Status code.
         */

        virtual int start() = 0;
        /**
         * @brief Stop camera stream.
         *
         * @return Return Status code.
         */
        virtual int stop() = 0;

        /**
         * @brief Read frame data from the camera.
         *
         * @param data_ptr  Address of the frame data
         * @param timestamp The timestamp of the frame.
         *
         * @return Return Status code.
         */
        virtual int getFrame(uint8_t *data_ptr, struct timeval &timestamp) = 0;
        
        /**
         * @brief Switch camera range.
         * 
         * @param value Mode value,
         * This parameter can be one of the following values:
         *          @arg  0 is 4m range mode
         *          @arg 1 is 2m range mode
         * @return Return Status code. 
         */
         virtual int setControl(ControlID mode, int value) = 0;
    };

} // namespace ArduCam

#endif
