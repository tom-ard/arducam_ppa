#ifndef __TOF_CSI_SENSOR_H
#define __TOF_CSI_SENSOR_H

#include <cstdint>
#include <string>
#include <fcntl.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <linux/videodev2.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <cstring>

#include "ArduCamTOFUnity.hpp"
#include "ArduCamTOFSensor.hpp"
namespace ArduCam
{
    struct DelegateCopyFunc
    {
        inline void jetson_nano_copy(struct v4l2_buffer &buffer, uint8_t *out_buffer, unsigned long int &offset, uint8_t *video_buffer_ptr[])
        {
            for (size_t buffer_offset = 0; buffer_offset < buffer.length; buffer_offset += 512, offset += 480)
            {
                memcpy(out_buffer + offset, video_buffer_ptr[buffer.index] + buffer_offset, 480);
            }
        }
        inline void default_copy(struct v4l2_buffer &buffer, uint8_t *out_buffer, unsigned long int &offset, uint8_t *video_buffer_ptr[])
        {
            memcpy(out_buffer + offset, video_buffer_ptr[buffer.index], buffer.length);
            offset += buffer.length;
        }
        inline void jetson_nx_copy(struct v4l2_buffer &buffer, uint8_t *out_buffer, unsigned long int &offset, uint8_t *video_buffer_ptr[]){
            for (size_t buffer_offset = 0; buffer_offset < buffer.length; buffer_offset += 960, offset += 960)
            {
                memcpy(out_buffer + offset, video_buffer_ptr[buffer.index] + buffer_offset, 448);
                memcpy(out_buffer + offset + 448, video_buffer_ptr[buffer.index] + buffer_offset + 896, 32);
                memcpy(out_buffer + offset + 480, video_buffer_ptr[buffer.index] + buffer_offset + 448, 480);
            }
        }
    };
    typedef void (DelegateCopyFunc::* DelegateType)(struct v4l2_buffer &buffer, uint8_t *out_buffer, unsigned long int &offset, uint8_t *video_buffer_ptr[]);

    /**
     * @brief Direct operation class for camera
     *
     */
    class ArduCamTOFCSISensor : public ArduCamTOFSensor
    {
#ifndef DOXYGEN_SHOULD_SKIP_THIS
    private:
        int tofd;

        int video_index;

        Platform _hw_name;

        char video_path[80];

        uint8_t *video_buffer_ptr[ARDUCAM_TOF_SENSOR_CACHE_BUFFER_COUNT];

        // typedef void (*DataCopy)(struct v4l2_buffer &buffer, uint8_t *out_buffer, unsigned long int &offset);

        DelegateCopyFunc delegate_func;

        DelegateType data_copy_func;

    private:
        inline int xioctl(int fh, int request, void *arg);

        inline int setRange(int value);

        inline int setExposure(int value);

        inline void jetsoncpy(struct v4l2_buffer &buffer, uint8_t *out_buffer, unsigned long int &offset);

        inline void defaultcpy(struct v4l2_buffer &buffer, uint8_t *out_buffer, unsigned long int &offset);

    public:
        ArduCamTOFCSISensor(const char *path = "/dev/video0");

        ArduCamTOFCSISensor(Platform hw_name, const char *path = "/dev/video0");

        ~ArduCamTOFCSISensor() = default;
#endif
    public:
        /**
         * @brief Open the camera specified by index and video
         *
         * @return Return Status code.
         */
        int open() override;

        /**
         * @brief Close camera
         *
         * @return Return Status code.
         */
        int close() override;

        /**
         * @brief Start the camera stream.
         *
         * @return Return Status code.
         */

        int start() override;
        /**
         * @brief Stop camera stream.
         *
         * @return Return Status code.
         */
        int stop() override;

        /**
         * @brief Read frame data from the camera.
         *
         * @param data_ptr  Address of the frame data
         * @param timestamp The timestamp of the frame.
         *
         * @return Return Status code.
         */
        int getFrame(uint8_t *data_ptr, struct timeval &timestamp) override;
        /**
         * @brief Set camera parameters
         *
         * @return Return Status code, The returned value can be: OK or ERROR(0 or -1).
         */
        int setControl(ControlID mode, int value) override;
    };
} // namespace ArduCam

#endif
