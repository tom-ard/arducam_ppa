
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was ArducamUvcStereoSdkConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)
if(ON)
    find_dependency(Threads REQUIRED)
endif()

include("${CMAKE_CURRENT_LIST_DIR}/ArducamUvcStereoSdkTargets.cmake")

set(_arducam_uvc_stereo_sdk_include_dir "${PACKAGE_PREFIX_DIR}/include")
set(_arducam_uvc_stereo_sdk_lib_dir "${PACKAGE_PREFIX_DIR}/lib/x86_64-linux-gnu")

if(NOT TARGET ArducamUvcStereoSdk::cpp_static)
    add_library(ArducamUvcStereoSdk::cpp_static STATIC IMPORTED)
    set_target_properties(ArducamUvcStereoSdk::cpp_static PROPERTIES
        IMPORTED_LOCATION "${_arducam_uvc_stereo_sdk_lib_dir}/libarducam_uvc_stereo_sdk.a"
        INTERFACE_INCLUDE_DIRECTORIES "${_arducam_uvc_stereo_sdk_include_dir}"
        INTERFACE_COMPILE_FEATURES "cxx_std_17"
        INTERFACE_LINK_LIBRARIES "Threads::Threads;rt"
    )
endif()

if(ON)
    if(NOT TARGET ArducamUvcStereoSdk::c_static)
        add_library(ArducamUvcStereoSdk::c_static STATIC IMPORTED)
        set_target_properties(ArducamUvcStereoSdk::c_static PROPERTIES
            IMPORTED_LOCATION "${_arducam_uvc_stereo_sdk_lib_dir}/libarducam_uvc_stereo_sdk_c.a"
            INTERFACE_INCLUDE_DIRECTORIES "${_arducam_uvc_stereo_sdk_include_dir}"
            INTERFACE_LINK_LIBRARIES "Threads::Threads;rt;stdc++"
        )
    endif()
endif()

check_required_components(ArducamUvcStereoSdk)
