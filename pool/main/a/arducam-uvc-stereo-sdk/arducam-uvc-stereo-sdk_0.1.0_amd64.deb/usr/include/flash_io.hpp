#ifndef ARDUCAM_UVC_STEREO_FLASH_IO_HPP
#define ARDUCAM_UVC_STEREO_FLASH_IO_HPP

#include <vector>

#include "flash_types.hpp"
#include "status.hpp"

namespace arducam::uvc_stereo {

Result<FlashBlob> parse_and_validate_raw_blob(const std::vector<uint8_t> &raw,
                                              const FlashConfig &config) noexcept;

Result<FlashBlob> build_blob(uint16_t version,
                             const std::vector<uint8_t> &payload,
                             const FlashConfig &config) noexcept;

Result<FlashBlob> read_blob_from_device(const FlashConfig &config) noexcept;

Status write_blob_to_device(const FlashConfig &config,
                            const FlashBlob &blob) noexcept;

uint32_t crc32_ieee(const std::vector<uint8_t> &data) noexcept;

} // namespace arducam::uvc_stereo

#endif // ARDUCAM_UVC_STEREO_FLASH_IO_HPP
