#ifndef ARDUCAM_UVC_STEREO_DEVICE_WHITELIST_HPP
#define ARDUCAM_UVC_STEREO_DEVICE_WHITELIST_HPP

#include <array>
#include <cstdint>

namespace arducam::uvc_stereo {

struct WhitelistEntry {
    uint16_t vid;
    uint16_t pid;
};

// Scan device whitelist
inline constexpr std::array<WhitelistEntry, 2> kDeviceVidPidWhitelist = {{
 {0x0c45, 0x0643},{0x0c45, 0x0645}
}};

} // namespace arducam::uvc_stereo

#endif // ARDUCAM_UVC_STEREO_DEVICE_WHITELIST_HPP
