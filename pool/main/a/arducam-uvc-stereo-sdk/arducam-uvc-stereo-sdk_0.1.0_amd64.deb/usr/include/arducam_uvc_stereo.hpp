#ifndef ARDUCAM_UVC_STEREO_FLASH_SDK_HPP
#define ARDUCAM_UVC_STEREO_FLASH_SDK_HPP

#include <cstdint>
#include <map>
#include <memory>
#include <optional>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace arducam::uvc_stereo {

/**
 * @brief Error codes used by C++ API.
 */
enum class ErrorCode {
    kOk = 0,                ///< Success – no error.
    kInvalidArgument,       ///< A function argument was invalid (e.g. empty JSON).
    kIoError,               ///< Generic I/O error (file system, USB transport).
    kDeviceInitFailed,      ///< Could not initialise the USB device handle.
    kDeviceReadFailed,      ///< Flash read operation failed.
    kDeviceWriteFailed,     ///< Flash write operation failed.
    kDeviceEraseFailed,     ///< Flash sector erase operation failed.
    kInvalidMagic,          ///< Flash header magic (0x41524455) mismatch.
    kUnsupportedVersion,    ///< Flash format version is not supported.
    kInvalidHeaderSize,     ///< Header size field is inconsistent.
    kInvalidTotalSize,      ///< Total payload size exceeds allowed bounds.
    kCrcMismatch,           ///< CRC-32 verification of the payload failed.
    kJsonError,             ///< JSON serialisation / deserialisation error.
    kInternalError,         ///< Unexpected internal error (bug).
};

/**
 * @brief Non-throwing status object used by all API methods.
 */
class Status {
public:
    /** @brief Construct an Ok status (default). */
    Status() = default;

    /**
     * @brief Construct an error status.
     * @param code  The error code.
     * @param message  Human-readable description of the error.
     */
    Status(ErrorCode code, std::string message)
        : code_(code), message_(std::move(message)) {}

    /** @brief Factory that returns an Ok status. */
    static Status Ok() { return Status(); }

    /** @brief Return @c true when the status represents success. */
    bool ok() const noexcept { return code_ == ErrorCode::kOk; }

    /** @brief Return the error code. */
    ErrorCode code() const noexcept { return code_; }

    /** @brief Return the human-readable error message (empty on success). */
    const std::string &message() const noexcept { return message_; }

private:
    ErrorCode code_ = ErrorCode::kOk;
    std::string message_;
};

/**
 * @brief Result wrapper for returning either value or Status.
 */
template <typename T>
class Result {
public:
    /** @brief Construct a Result holding a failed Status. */
    Result(const Status &status) : status_(status) {}

    /** @overload */
    Result(Status &&status) : status_(std::move(status)) {}

    /** @brief Construct a Result holding a success value (copy). */
    Result(const T &value) : status_(Status::Ok()), value_(value) {}

    /** @brief Construct a Result holding a success value (move). */
    Result(T &&value) : status_(Status::Ok()), value_(std::move(value)) {}

    /** @brief Return @c true when the Result holds a value. */
    bool ok() const noexcept { return status_.ok(); }

    /** @brief Return the underlying Status. */
    const Status &status() const noexcept { return status_; }

    /**
     * @brief Access the stored value (const).
     * @pre ok() must be @c true; otherwise behaviour is undefined.
     */
    const T &value() const { return value_.value(); }

    /**
     * @brief Access the stored value (mutable).
     * @pre ok() must be @c true; otherwise behaviour is undefined.
     */
    T &value() { return value_.value(); }

    /**
     * @brief Move the stored value out of the Result.
     * @pre ok() must be @c true; otherwise behaviour is undefined.
     */
    T move_value() { return std::move(value_.value()); }

private:
    Status status_;
    std::optional<T> value_;
};

/**
 * @brief OpenCV VideoCapture backend identifiers supported by this SDK.
 *
 * The enum values intentionally match OpenCV's ``cv::VideoCaptureAPIs`` so
 * callers can pass ``static_cast<int>(backend)`` directly to
 * ``cv::VideoCapture(index, backend)``.
 */
enum class OpenCvBackend : int32_t {
    CAP_V4L2 = 200,
    CAP_DSHOW = 700,
    CAP_MSMF = 1400,
    CAP_GSTREAMER = 1800,
};

using OpenCvBackendIndexMap = std::map<OpenCvBackend, int32_t>;

/**
 * @brief Return the symbolic OpenCV backend name.
 *
 * Useful when displaying the entries stored in DeviceInfo::opencv_backend_indices.
 */
std::string_view opencv_backend_name(OpenCvBackend backend) noexcept;

/**
 * @brief Information about one discovered Arducam USB device.
 */
struct DeviceInfo {
    uint16_t vid = 0;           ///< USB Vendor ID.
    uint16_t pid = 0;           ///< USB Product ID.
    uint8_t bus_number = 0;     ///< USB bus number.
    uint8_t device_address = 0; ///< USB device address on the bus.
    std::string serial_number;  ///< USB serial number string (may be empty).
    std::string manufacturer;   ///< USB manufacturer descriptor.
    std::string product;        ///< USB product descriptor.
    std::string video_node;     ///< V4L2 video device node (e.g. ``/dev/video0``).
    std::string device_path;    ///< Sysfs device path.
    OpenCvBackendIndexMap opencv_backend_indices; ///< OpenCV backend -> index mapping.
};

/**
 * @brief Result returned by UVCStereo::read_json().
 */
struct ReadJsonResult {
    uint16_t version = 0;  ///< Flash format version.
    std::string json_utf8; ///< JSON payload (UTF-8).
};

/**
 * @brief SDK object for reading and writing JSON to device flash.
 *
 * Create one instance and reuse it across multiple calls.
 * All public methods except the constructor are noexcept; errors are
 * reported via Status / Result<T>, never by throwing exceptions.
 */
class UVCStereo {
public:
    /**
     * @brief Construct with default configuration.
     */
    UVCStereo();

    /** @brief Destructor. */
    ~UVCStereo();

    /** @brief Copy constructor (deep copy). */
    UVCStereo(const UVCStereo &other);

    /** @brief Copy assignment operator (deep copy). */
    UVCStereo &operator=(const UVCStereo &other);

    /** @brief Move constructor. */
    UVCStereo(UVCStereo &&other) noexcept;

    /** @brief Move assignment operator. */
    UVCStereo &operator=(UVCStereo &&other) noexcept;

    /**
     * @brief Scan the system for connected Arducam devices.
     *
     * @return Result holding a (possibly empty) vector of DeviceInfo on
     *         success, or a failed Status.
     */
    Result<std::vector<DeviceInfo>> scan() noexcept;

    /**
     * @brief Read JSON from device flash using constructor config.
     *
     * @return Result<ReadJsonResult> on success, or a failed Status.
     */
    Result<ReadJsonResult> read_json() noexcept;

    /**
     * @brief Read JSON from a specific device.
     *
     * @param device The target device obtained from scan().
     * @return Result<ReadJsonResult> on success, or a failed Status.
     */
    Result<ReadJsonResult> read_json(const DeviceInfo &device) noexcept;

    /**
     * @brief Write JSON to device flash using constructor config.
     *
     * @warning Permanently erases the configured flash region
     *          (default: 0x51000).
     *
     * @param json_utf8 A valid UTF-8 JSON string.
     * @return Status - check Status::ok().
     */
    Status write_json(std::string_view json_utf8) noexcept;

    /**
     * @brief Write JSON to a specific device.
     *
     * @warning Permanently erases the configured flash region
     *          (default: 0x51000).
     *
     * @param json_utf8 A valid UTF-8 JSON string.
     * @param device The target device obtained from scan().
     * @return Status - check Status::ok().
     */
    Status write_json(std::string_view json_utf8, const DeviceInfo &device) noexcept;

private:
    class Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace arducam::uvc_stereo

#endif // ARDUCAM_UVC_STEREO_FLASH_SDK_HPP
