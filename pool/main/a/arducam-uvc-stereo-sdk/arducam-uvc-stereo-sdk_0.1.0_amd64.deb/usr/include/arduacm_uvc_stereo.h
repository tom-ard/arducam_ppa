#ifndef ARDUCAM_UVC_STEREO_FLASH_H
#define ARDUCAM_UVC_STEREO_FLASH_H

#include <stddef.h>
#include <stdint.h>

#if !defined(ARDUCAM_UVC_STEREO_API)
#if defined(_WIN32)
#if defined(ARDUCAM_UVC_STEREO_BUILD_SHARED)
#define ARDUCAM_UVC_STEREO_API __declspec(dllexport)
#elif defined(ARDUCAM_UVC_STEREO_USE_SHARED)
#define ARDUCAM_UVC_STEREO_API __declspec(dllimport)
#else
#define ARDUCAM_UVC_STEREO_API
#endif
#elif defined(ARDUCAM_UVC_STEREO_BUILD_SHARED)
#define ARDUCAM_UVC_STEREO_API __attribute__((visibility("default")))
#else
#define ARDUCAM_UVC_STEREO_API
#endif
#endif

#define ARDUCAM_UVC_STEREO_VERSION_MAJOR 0
#define ARDUCAM_UVC_STEREO_VERSION_MINOR 1
#define ARDUCAM_UVC_STEREO_VERSION_PATCH 0

#define ARDUCAM_UVC_STEREO_DEFAULT_FLASH_MAGIC 0x41524455u
#define ARDUCAM_UVC_STEREO_DEFAULT_FLASH_ADDRESS 0x51000u
#define ARDUCAM_UVC_STEREO_DEFAULT_ERASE_SECTOR_SIZE 0x1000u
#define ARDUCAM_UVC_STEREO_DEFAULT_MAX_TOTAL_SIZE (64u * 1024u)
#define ARDUCAM_UVC_STEREO_DEFAULT_HEADER_MIN_SIZE 16u
#define ARDUCAM_UVC_STEREO_DEFAULT_HEADER_MAX_SIZE 256u
#define ARDUCAM_UVC_STEREO_FLASH_FORMAT_V0 0u
#define ARDUCAM_UVC_STEREO_DEVICE_TEXT_MAX 256u
#define ARDUCAM_UVC_STEREO_DEVICE_PATH_MAX 512u
#define ARDUCAM_UVC_STEREO_OPENCV_BACKEND_INDEX_MAX 8u

typedef struct arducam_uvc_stereo_handle arducam_uvc_stereo_handle_t;

typedef enum arducam_uvc_stereo_error_code {
    ARDUCAM_UVC_STEREO_OK = 0,
    ARDUCAM_UVC_STEREO_ERR_INVALID_ARGUMENT = 1,
    ARDUCAM_UVC_STEREO_ERR_IO_ERROR = 2,
    ARDUCAM_UVC_STEREO_ERR_DEVICE_INIT_FAILED = 3,
    ARDUCAM_UVC_STEREO_ERR_DEVICE_READ_FAILED = 4,
    ARDUCAM_UVC_STEREO_ERR_DEVICE_WRITE_FAILED = 5,
    ARDUCAM_UVC_STEREO_ERR_DEVICE_ERASE_FAILED = 6,
    ARDUCAM_UVC_STEREO_ERR_INVALID_MAGIC = 7,
    ARDUCAM_UVC_STEREO_ERR_UNSUPPORTED_VERSION = 8,
    ARDUCAM_UVC_STEREO_ERR_INVALID_HEADER_SIZE = 9,
    ARDUCAM_UVC_STEREO_ERR_INVALID_TOTAL_SIZE = 10,
    ARDUCAM_UVC_STEREO_ERR_CRC_MISMATCH = 11,
    ARDUCAM_UVC_STEREO_ERR_JSON_ERROR = 12,
    ARDUCAM_UVC_STEREO_ERR_INTERNAL_ERROR = 13,
} arducam_uvc_stereo_error_code_t;

/**
 * @brief OpenCV VideoCapture backend identifiers supported by this SDK.
 *
 * The numeric values intentionally match OpenCV's cv::VideoCaptureAPIs so
 * callers can pass them directly to cv::VideoCapture(index, backend).
 */
typedef enum arducam_uvc_stereo_opencv_backend {
    ARDUCAM_UVC_STEREO_OPENCV_BACKEND_CAP_V4L2 = 200,
    ARDUCAM_UVC_STEREO_OPENCV_BACKEND_CAP_DSHOW = 700,
    ARDUCAM_UVC_STEREO_OPENCV_BACKEND_CAP_MSMF = 1400,
    ARDUCAM_UVC_STEREO_OPENCV_BACKEND_CAP_GSTREAMER = 1800
} arducam_uvc_stereo_opencv_backend_t;

/**
 * @brief One OpenCV backend/index pair for a discovered device.
 */
typedef struct arducam_uvc_stereo_opencv_backend_index_entry {
    arducam_uvc_stereo_opencv_backend_t backend;
    int32_t index;
} arducam_uvc_stereo_opencv_backend_index_entry_t;

typedef struct arducam_uvc_stereo_config {
    uint32_t flash_address;
    uint32_t erase_sector_size;
    uint32_t flash_magic;
    uint32_t max_total_size;
    uint16_t min_header_size;
    uint16_t max_header_size;
    int strict_crc;
    int verify_after_write;
} arducam_uvc_stereo_config_t;

/**
 * @brief Information about one discovered Arducam USB device.
 */
typedef struct arducam_uvc_stereo_device_info {
    uint16_t vid;
    uint16_t pid;
    uint8_t bus_number;
    uint8_t device_address;
    char serial_number[ARDUCAM_UVC_STEREO_DEVICE_TEXT_MAX];
    char manufacturer[ARDUCAM_UVC_STEREO_DEVICE_TEXT_MAX];
    char product[ARDUCAM_UVC_STEREO_DEVICE_TEXT_MAX];
    char video_node[ARDUCAM_UVC_STEREO_DEVICE_PATH_MAX];
    char device_path[ARDUCAM_UVC_STEREO_DEVICE_PATH_MAX];
    size_t opencv_backend_index_count;
    arducam_uvc_stereo_opencv_backend_index_entry_t
        opencv_backend_indices[ARDUCAM_UVC_STEREO_OPENCV_BACKEND_INDEX_MAX];
} arducam_uvc_stereo_device_info_t;

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Scan the system for connected Arducam devices.
 *
 * On success `*out_devices` points to a heap-allocated array of
 * `*out_count` arducam_uvc_stereo_device_info_t elements.
 * The caller **must** free it with arducam_uvc_stereo_free(), even when `*out_count == 0`.
 *
 * @param[out] out_devices  Receives the pointer to the device array.
 * @param[out] out_count    Receives the number of devices found.
 * @return ARDUCAM_UVC_STEREO_OK on success, or a non-zero arducam_uvc_stereo_error_code_t on failure.
 *
 * @code{.c}
 * arducam_uvc_stereo_device_info_t *devs = NULL;
 * size_t n = 0;
 * int32_t rc = arducam_uvc_stereo_scan_devices(&devs, &n);
 * if (rc != ARDUCAM_UVC_STEREO_OK || n == 0) { arducam_uvc_stereo_free(devs); return; }
 * arducam_uvc_stereo_device_info_t dev = devs[0];
 * arducam_uvc_stereo_free(devs);
 * @endcode
 */
ARDUCAM_UVC_STEREO_API int32_t arducam_uvc_stereo_scan_devices(
    arducam_uvc_stereo_device_info_t **out_devices,
    size_t *out_count);

/**
 * @brief Read a JSON string from the device flash.
 *
 * On success:
 * - `*out_version` is set to the format version stored in the flash header.
 * - `*out_json_utf8` is a heap-allocated, NUL-terminated UTF-8 string.
 * - `*out_json_utf8_len` is the byte length (excluding the NUL terminator).
 *
 * The caller **must** free `*out_json_utf8` with arducam_uvc_stereo_free().
 *
 * @param[in]  device            Target device.
 * @param[out] out_version       Receives the flash format version.
 * @param[out] out_json_utf8     Receives the JSON string pointer.
 * @param[out] out_json_utf8_len Receives the JSON string byte length.
 * @return ARDUCAM_UVC_STEREO_OK on success, or a non-zero arducam_uvc_stereo_error_code_t on failure.
 *
 * @code{.c}
 * uint16_t version = 0;
 * char *json = NULL;
 * size_t json_len = 0;
 * int32_t rc = arducam_uvc_stereo_read_json(&dev, &version, &json, &json_len);
 * if (rc == ARDUCAM_UVC_STEREO_OK) {
 *     printf("v=%u %.*s\n", version, (int)json_len, json);
 *     arducam_uvc_stereo_free(json);
 * }
 * @endcode
 */
ARDUCAM_UVC_STEREO_API int32_t arducam_uvc_stereo_read_json(
    const arducam_uvc_stereo_device_info_t *device,
    uint16_t *out_version,
    char **out_json_utf8,
    size_t *out_json_utf8_len);

/**
 * @brief Write a JSON string to the device flash.
 *
 * Erases the required flash sectors before writing.
 * `json_utf8` does not need a NUL terminator; the length is given via
 * `json_utf8_len`.
 *
 * @warning This operation permanently erases the flash region at the
 *          configured address (default: @c 0x51000).
 *
 * @param[in] device        Target device.
 * @param[in] json_utf8     UTF-8 encoded JSON string.
 * @param[in] json_utf8_len Byte length of @p json_utf8.
 * @return ARDUCAM_UVC_STEREO_OK on success, or a non-zero arducam_uvc_stereo_error_code_t on failure.
 *
 * @code{.c}
 * const char *json = "{\"key\":\"value\"}";
 * int32_t rc = arducam_uvc_stereo_write_json(&dev, json, strlen(json));
 * @endcode
 */
ARDUCAM_UVC_STEREO_API int32_t arducam_uvc_stereo_write_json(
    const arducam_uvc_stereo_device_info_t *device,
    const char *json_utf8,
    size_t json_utf8_len);

/**
 * @brief Return the symbolic OpenCV backend name.
 *
 * This is useful when displaying entries from
 * arducam_uvc_stereo_device_info_t::opencv_backend_indices.
 */
ARDUCAM_UVC_STEREO_API const char *arducam_uvc_stereo_opencv_backend_name(
    arducam_uvc_stereo_opencv_backend_t backend);

/**
 * @brief Retrieve the last error message on the calling thread.
 *
 * The returned pointer is valid until the next SDK call on the same thread.
 * Do **not** free it.
 *
 * @param[out] out_message     Receives a pointer to the error string.
 * @param[out] out_message_len Receives the byte length of the string.
 * @return ARDUCAM_UVC_STEREO_OK always.
 *
 * @code{.c}
 * const char *msg;
 * size_t len;
 * arducam_uvc_stereo_last_error_message(&msg, &len);
 * fprintf(stderr, "error: %.*s\n", (int)len, msg);
 * @endcode
 */
ARDUCAM_UVC_STEREO_API int32_t arducam_uvc_stereo_last_error_message(
    const char **out_message,
    size_t *out_message_len);

/**
 * @brief Free memory allocated by the SDK.
 *
 * Pass the pointer returned by arducam_uvc_stereo_scan_devices() or arducam_uvc_stereo_read_json().
 * Passing @c NULL is safe and has no effect.
 *
 * @param[in] ptr Pointer to free, or @c NULL.
 */
ARDUCAM_UVC_STEREO_API void arducam_uvc_stereo_free(void *ptr);

#ifdef __cplusplus
}
#endif

#endif // ARDUCAM_UVC_STEREO_FLASH_H
