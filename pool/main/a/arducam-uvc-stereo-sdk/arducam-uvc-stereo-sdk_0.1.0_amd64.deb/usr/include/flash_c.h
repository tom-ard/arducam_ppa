#ifndef ARDUCAM_UVC_STEREO_C_H
#define ARDUCAM_UVC_STEREO_C_H

#include "arduacm_uvc_stereo.h"

#ifdef __cplusplus
extern "C" {
#endif

ARDUCAM_UVC_STEREO_API void arducam_uvc_stereo_ctx_config_init_default(
    arducam_uvc_stereo_config_t *out_config);

ARDUCAM_UVC_STEREO_API int32_t arducam_uvc_stereo_ctx_create(
    const arducam_uvc_stereo_config_t *config,
    arducam_uvc_stereo_handle_t **out_handle);

ARDUCAM_UVC_STEREO_API void arducam_uvc_stereo_ctx_destroy(
    arducam_uvc_stereo_handle_t *handle);

ARDUCAM_UVC_STEREO_API int32_t arducam_uvc_stereo_ctx_scan(
    arducam_uvc_stereo_handle_t *handle,
    arducam_uvc_stereo_device_info_t *out_device);

ARDUCAM_UVC_STEREO_API int32_t arducam_uvc_stereo_ctx_read_json(
    arducam_uvc_stereo_handle_t *handle,
    const arducam_uvc_stereo_device_info_t *device,
    uint16_t *out_version,
    char **out_json_utf8,
    size_t *out_json_utf8_len);

ARDUCAM_UVC_STEREO_API int32_t arducam_uvc_stereo_ctx_write_json(
    arducam_uvc_stereo_handle_t *handle,
    const arducam_uvc_stereo_device_info_t *device,
    const char *json_utf8,
    size_t json_utf8_len);

ARDUCAM_UVC_STEREO_API int32_t arducam_uvc_stereo_ctx_last_error_message(
    const arducam_uvc_stereo_handle_t *handle,
    const char **out_message,
    size_t *out_message_len);

#ifdef __cplusplus
}
#endif

#endif // ARDUCAM_UVC_STEREO_C_H
