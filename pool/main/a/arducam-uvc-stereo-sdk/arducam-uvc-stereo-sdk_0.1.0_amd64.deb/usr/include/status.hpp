#ifndef ARDUCAM_UVC_STEREO_STATUS_HPP
#define ARDUCAM_UVC_STEREO_STATUS_HPP

/**
 * @brief Backward-compatible include path.
 *
 * Status / ErrorCode / Result are now defined in arducam_uvc_stereo.hpp
 * to support single-header C++ integration.
 */
#include "arducam_uvc_stereo.hpp"

#endif // ARDUCAM_UVC_STEREO_STATUS_HPP
