#ifndef ARDUCAM_UVC_STEREO_JSON_MINIFIER_HPP
#define ARDUCAM_UVC_STEREO_JSON_MINIFIER_HPP

#include <string>
#include <string_view>

#include "status.hpp"

namespace arducam::uvc_stereo {

Result<std::string> minify_and_validate_json(std::string_view json_text) noexcept;

} // namespace arducam::uvc_stereo

#endif // ARDUCAM_UVC_STEREO_JSON_MINIFIER_HPP
