#ifndef ARDUCAM_UVC_STEREO_DEVICE_SCAN_HPP
#define ARDUCAM_UVC_STEREO_DEVICE_SCAN_HPP

#include <optional>

#include "arducam_uvc_stereo.hpp"

namespace arducam::uvc_stereo {

/**
 * @brief Optional scan filter for low-level scan_devices().
 */
struct DeviceScanFilter {
    std::optional<uint16_t> vid;
    std::optional<uint16_t> pid;
    bool require_serial = false;
};

/**
 * @brief Low-level device scan API.
 */
Result<std::vector<DeviceInfo>> scan_devices(const DeviceScanFilter &filter) noexcept;

} // namespace arducam::uvc_stereo

#endif // ARDUCAM_UVC_STEREO_DEVICE_SCAN_HPP
