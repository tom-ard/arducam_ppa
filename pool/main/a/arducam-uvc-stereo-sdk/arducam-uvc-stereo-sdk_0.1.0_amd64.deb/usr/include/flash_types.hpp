#ifndef ARDUCAM_UVC_STEREO_FLASH_TYPES_HPP
#define ARDUCAM_UVC_STEREO_FLASH_TYPES_HPP

#include <cstdint>
#include <string>
#include <vector>

#include "arducam_uvc_stereo.hpp"

namespace arducam::uvc_stereo {

/**
 * @brief Default flash constants (advanced configuration use).
 *
 * Similar to ARDUCAM_UVC_STEREO_DEFAULT_* macros in C API's extended header.
 */
constexpr uint32_t kDefaultFlashMagic = 0x41524455u;
constexpr uint16_t kDefaultHeaderMinSize = 16u;
constexpr uint16_t kDefaultHeaderMaxSize = 256u;
constexpr uint32_t kDefaultFlashAddress = 0x51000u;
constexpr uint32_t kDefaultEraseSectorSize = 0x1000u;
constexpr uint32_t kDefaultMaxTotalSize = 64u * 1024u;
constexpr uint16_t kFlashFormatV0 = 0u;

/**
 * @brief Runtime configuration for flash read/write.
 *
 * This is an advanced configuration type. Mainline C++ usage can rely on
 * UVCStereo() defaults from arducam_uvc_stereo.hpp.
 */
struct FlashConfig {
    std::string vidpid;
    bool auto_select_vidpid = true;
    uint16_t auto_select_vid = 0;
    uint16_t auto_select_pid = 0;
    uint8_t bus_number = 0;
    uint8_t device_address = 0;
    std::string preferred_serial_number;
    std::string preferred_device_path;

    uint32_t flash_address = kDefaultFlashAddress;
    uint32_t erase_sector_size = kDefaultEraseSectorSize;
    uint32_t flash_magic = kDefaultFlashMagic;
    uint32_t max_total_size = kDefaultMaxTotalSize;
    uint16_t min_header_size = kDefaultHeaderMinSize;
    uint16_t max_header_size = kDefaultHeaderMaxSize;
    bool strict_crc = true;
    bool verify_after_write = true;
};

/**
 * @brief Parsed flash header.
 */
struct FlashHeader {
    uint32_t magic = 0;
    uint16_t version = 0;
    uint16_t header_size = 0;
    uint32_t payload_len = 0;
    uint32_t crc32_payload = 0;
};

/**
 * @brief Parsed flash blob (header + payload + raw bytes).
 */
struct FlashBlob {
    FlashHeader header;
    std::vector<uint8_t> payload;
    std::vector<uint8_t> raw;
};

} // namespace arducam::uvc_stereo

#endif // ARDUCAM_UVC_STEREO_FLASH_TYPES_HPP
