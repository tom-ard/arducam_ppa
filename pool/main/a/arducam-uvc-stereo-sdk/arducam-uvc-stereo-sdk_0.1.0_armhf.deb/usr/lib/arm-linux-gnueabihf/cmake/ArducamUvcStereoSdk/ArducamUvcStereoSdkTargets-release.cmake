#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ArducamUvcStereoSdk::cpp_shared" for configuration "Release"
set_property(TARGET ArducamUvcStereoSdk::cpp_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ArducamUvcStereoSdk::cpp_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/libarducam_uvc_stereo_sdk.so"
  IMPORTED_SONAME_RELEASE "libarducam_uvc_stereo_sdk.so"
  )

list(APPEND _cmake_import_check_targets ArducamUvcStereoSdk::cpp_shared )
list(APPEND _cmake_import_check_files_for_ArducamUvcStereoSdk::cpp_shared "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/libarducam_uvc_stereo_sdk.so" )

# Import target "ArducamUvcStereoSdk::c_shared" for configuration "Release"
set_property(TARGET ArducamUvcStereoSdk::c_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ArducamUvcStereoSdk::c_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/libarducam_uvc_stereo_sdk_c.so"
  IMPORTED_SONAME_RELEASE "libarducam_uvc_stereo_sdk_c.so"
  )

list(APPEND _cmake_import_check_targets ArducamUvcStereoSdk::c_shared )
list(APPEND _cmake_import_check_files_for_ArducamUvcStereoSdk::c_shared "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/libarducam_uvc_stereo_sdk_c.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
